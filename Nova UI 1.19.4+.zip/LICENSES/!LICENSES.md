# MIT License
Armor Hud
- Directory: assets/armor_hud
- Source: https://github.com/SaolGhra/Armor-Hud
---
Armor Hud by Mcjunky33
- Directory: assets/armor_hud
- Source: https://github.com/Mcjunky33/ArmorHudMod
---
Auth Me
- Directory: assets/authme
- Source: https://github.com/axieum/authme
---
Chest Search Bar
- Directory: assets/chestsearchbar
- Source: https://modrinth.com/project/FqlAuAzY
---
Dark OreUI Recreation
- Directory: format_85_plus/assets/minecraft/shaders/core/text.fsh
- Source: https://github.com/thetmc249/OreUI-Recreation
---
Detail Armor Bar
- Directory: assets/detailab
- Source: https://github.com/RedLime/DetailArmorBar
---
Detail Armor Bar Reconstructed
- Directory: assets/detailab
- Source: https://github.com/coredex-source/DetailArmorBarReconstructed
---
EMI
- Directory: assets/emi
- Source: https://github.com/emilyploszaj/emi
---
Cursors Extended
- Directories: 
  - assets/cursors_extended
  - assets/minecraft-cursor
- Source: https://github.com/fishstiz/cursors_extended

Pixel Cursors
- Directories: 
  - assets/cursors_extended/textures/gui/sprites/cursors
  - assets/cursors_extended/rpo/textures/gui/sprites/cursors
  - assets/minecraft-cursor/textures//cursors
  - assets/minecraft-cursor/rpo/textures//cursors
- Source: https://modrinth.com/project/5f7SMVUe
---
Inventory Item Groups
- Directory: assets/inventory_item_groups
- Source: https://github.com/BizCub/inventory-item-groups
---
Just Enough Items
- Directory: assets/jei
- Source: https://github.com/mezz/JustEnoughItems
---
Language Reload
- Directory: assets/languagereload
- Source: https://github.com/Jerozgen/LanguageReload
---
Legacy4J
- Directory: assets/legacy
- Source: https://github.com/Wilyicaro/Legacy-Minecraft
---
MidnightLib
- Directory: assets/midnightlib
- Source: https://github.com/TeamMidnightDust/MidnightLib
---
Mod Menu
- Directory: assets/modmenu
- Source: https://github.com/TerraformersMC/ModMenu
---
oωo
- Directory: assets/owo
- Source: https://github.com/wisp-forest/owo-lib
---
Packed Packs
- Directory: assets/packed_packs
- Source: https://github.com/fishstiz/packed_packs
---
Puzzle
- Directory: assets/puzzle
- Source: https://github.com/PuzzleMC/Puzzle
---
Show Me Your Skin!
- Directory: assets/showmeyourskin
- Source: https://codeberg.org/enjarai/show-me-your-skin
---
Shulker Box Tooltip
- Directory: assets/shulkerboxtooltip
- Source: https://github.com/MisterPeModder/ShulkerBoxTooltip
---
Trinkets
- Directory: assets/trinkets
- Source: https://github.com/emilyploszaj/trinkets
# Apache License 2.0
Chat Notify
- Directories: assets/chatnotify, format_16_plus/assets/chatnotify
- Source: https://github.com/TerminalMC/ChatNotify
- Modified by: SmafisNova
Client Sort
- Directory: assets/clientsort
- Source: https://github.com/TerminalMC/ClientSort
- Modified by: SmafisNova
Command Keys
- Directories: assets/commandkeys, format_16_plus/assets/commandkeys
- Source: https://github.com/TerminalMC/CommandKeys/
- Modified by: SmafisNova
---
Fabric API
- Directories: assets/fabric, format_34_plus/assets/fabric
- Source: https://github.com/FabricMC/fabric-api
- Modified by: SmafisNova
# GNU General Public License v3.0 only
BedrockIfy
- Directory: assets/bedrockify
- Source: https://github.com/juancarloscp52/BedrockIfy/
- Modified by: SmafisNova
- Last modified: 2026-06-11
# GNU Lesser General Public License v3.0 or later
Cherished Worlds
- Directory: assets/cherishedworlds
- Source: https://github.com/illusivesoulworks/cherishedworlds
- Modified by: SmafisNova
- Last modified: 2026-04-29
---
Raised
- Directory: assets/raised
- Source: https://github.com/yurisuika/Raised
- Modified by: SmafisNova
- Last modified: 2026-04-21
# GNU Lesser General Public License v3.0 only
Chat Patches
- Directory: assets/chatpatches
- Source: https://github.com/mrbuilder1961/ChatPatches
- Modified by: SmafisNova
- Last modified: 2026-06-12
Cloth Config API
- Directory: assets/cloth-config2
- Source: https://github.com/shedaniel/cloth-config
- Modified by: SmafisNova
- Last modified: 2026-05-03
---
Distant Horizons
- Directory: assets/distanthorizons
- Source: https://gitlab.com/distant-horizons-team/distant-horizons
- Modified by: SmafisNova
- Last modified: 2026-02-16
---
Dynamic Crosshair
- Directory: assets/dynamiccrosshair
- Source: https://github.com/Crendgrim/DynamicCrosshair
- Modified by: SmafisNova
- Last modified: 2026-05-04
---
Entity Model Features
- Directory: assets/entity_features
- Source: https://github.com/Traben-0/Entity_Model_Features
- Modified by: SmafisNova
- Last modified: 2026-02-12
---
Entity Sound Features
- Directory: assets/entity_features
- Source: https://github.com/Traben-0/entity_sound_features
- Modified by: SmafisNova
- Last modified: 2026-02-12
---
Entity Texture Features
- Directory: assets/entity_features
- Source: https://github.com/Traben-0/Entity_Texture_Features
- Modified by: SmafisNova
- Last modified: 2026-02-12
---
Litematica
- Directory: assets/litematica
- Source: https://github.com/maruohon/litematica/
- Modified by: SmafisNova
- Last modified: 2026-05-03
---
MaLiLib
- Directory: assets/malilib
- Source: https://github.com/maruohon/malilib/
- Modified by: SmafisNova
- Last modified: 2026-05-03
# GNU Affero General Public License v3.0 or later
Inventory Profiles Next
- Directory: assets/inventoryprofilesnext
- Source: https://inventory-profiles-next.github.io/
- Modified by: SmafisNova
- Last modified: 2026-05-03
---
LibIPN
- Directory: assets/libipn
- Source: https://github.com/blackd/libIPN
- Modified by: SmafisNova
- Last modified: 2026-05-03
# GNU Lesser General Public License v2.1 only
Capes
- Directory: assets/capes
- Source: https://github.com/CaelTheColher/Capes
- Modified by: SmafisNova
- Modified on: 2026-04-23
# Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
AppleSkin
- Directory: assets/appleskin
- Original license: Unlicense
- Source: https://github.com/squeek502/AppleSkin
- Distributed in this project under: CC-BY-NC-SA-4.0
---
Bundles Beyond
- Directory: assets/bundlesbeyond
- Source: https://github.com/O7410/Bundles-Beyond
- Modified: Yes
---
Default Dark Mode
- Directories: format_76_plus/assets/minecraft/shaders/core/rendertype_text.fsh, rendertype_text_intensity.fsh
- Source: https://github.com/nebuIr/Default-Dark-Mode
- Modified: Yes
---
Enchanted's Sodium Options
- Directory: assets/enchanteds_sodium_options
- Source: https://github.com/Enchanted-Games/enchanteds-sodium-options
- Modified: Yes
---
No Chat Reports
- Directory: assets/nochatreports
- Original license: WTFPL
- Source: https://github.com/Aizistral-Studios/No-Chat-Reports
- Distributed in this project under: CC-BY-NC-SA-4.0
# Multiple Licenses
ReplayMod
- Directories: assets/replaymod, assets/jgui
  - License: GPL-3.0-or-later
  - Modified by: SmafisNova
  - Last modified: 2026-04-26
- Directory: assets/replaymod/replay_gui.png
  - License: MIT
- Source: https://github.com/ReplayMod/ReplayMod
# All Rights Reserved
Axiom
- Directory: assets/axiom
- Copyright holder: Moulberry
- Granted permissions: Permission has been granted to use and redistribute Axiom assets, including modified versions of those assets, within a non-commercial dark mode resource pack distributed on Modrinth.
- Permission evidence: [Discord > Axiom > #support > Can I add Axiom support to my resource pack?](https://discord.com/channels/1123229768087777330/1504843195811495996)
- Source: https://modrinth.com/mod/axiom
---
Bartering Station
- Directory: assets/barteringstation
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/bartering-station
---
Camera Mod
- Directory: assets/camera
- Copyright holder: henkelmax
- Granted permissions: Permission was granted by the copyright holder to include and redistribute support for their mod in this project, provided that no original mod icons or logos are included.
- Permission evidence: [Discord > Simple Voice Chat > #support-threats > Support thread for smafisnova](https://discord.com/channels/854659575324344340/1497237531169915011)
- Source: https://github.com/henkelmax/camera
---
Camera Utils
- Directory: assets/camerautils
- Copyright holder: henkelmax
- Granted permissions: Permission was granted by the copyright holder to include and redistribute support for their mod in this project, provided that no original mod icons or logos are included.
- Permission evidence: [Discord > Simple Voice Chat > #support-threats > Support thread for smafisnova](https://discord.com/channels/854659575324344340/1497237531169915011)
- Source: https://github.com/henkelmax/camera-utils
---
Corpse
- Directory: assets/corpse
- Copyright holder: henkelmax
- Granted permissions: Permission was granted by the copyright holder to include and redistribute support for their mod in this project, provided that no original mod icons or logos are included.
- Permission evidence: [Discord > Simple Voice Chat > #support-threats > Support thread for smafisnova](https://discord.com/channels/854659575324344340/1497237531169915011)
- Source: https://github.com/henkelmax/corpse
---
Easy Anvils
- Directory: assets/easyanvils
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/easy-anvils
---
Easy Magic
- Directory: assets/easymagic
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/easy-magic
---
Easy Shulker Boxes
- Directory: assets/easyshulkerboxes
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/easy-shulker-boxes
---
Item Interactions
- Directories: assets/iteminteractions, assets/iteminteractionscore
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Sources: https://github.com/Fuzss/item-interactions, https://github.com/Fuzss/iteminteractionscore
---
Name Tag Upgrade
- Directory: assets/nametagupgrade
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/name-tag-upgrade
---
Overflowing Bars
- Directory: assets/overflowingbars
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/overflowingbars
---
Puzzles API
- Directory: assets/puzzlesapi
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/puzzlesapi
---
RP Renames
- Directory: assets/rprenames
- Copyright holder: HiWord9
- Granted pemissions: Permission has been granted to add modified assets from the mod into this project, including the right to distribute them publicly.
- Permission evidence: [Discord > HiWord9's realm > #chat-en at 2026-06-27, 18:01](https://discord.com/channels/1165929315964289094/1278793951511449731/1541477481280970802)
- Source: https://github.com/HiWord9/RPRenames
---
Simple Voice Chat
- Directory: assets/voicechat
- Copyright holder: henkelmax
- Granted permissions: Permission was granted by the copyright holder to include and redistribute support for their mod in this project, provided that no original mod icons or logos are included.
- Permission evidence: [Discord > Simple Voice Chat > #support-threats > Support thread for smafisnova](https://discord.com/channels/854659575324344340/1497237531169915011)
- Source: https://github.com/henkelmax/simple-voice-chat
---
Statue Menus
- Directory: assets/statuemenus
- Copyright holder: fuzs
- Granted permissions: Permission has been granted to add support for a dark mode resource pack to all projects containing a GUI, regardless of the restrictions in the LICENSE-ASSETS.md files.
- Permission evidence: [Discord > Luna Pixel Studios > #fuzs-projects at 2026-06-27, 07:46](https://discord.com/channels/790272037578473512/917550806922846299/1520301812782207017)
- Source: https://github.com/Fuzss/statue-menus
---
Trade Cycling
- Directory: assets/trade_cycling
- Copyright holder: henkelmax
- Granted permissions: Permission was granted by the copyright holder to include and redistribute support for their mod in this project, provided that no original mod icons or logos are included.
- Permission evidence: [Discord > Simple Voice Chat > #support-threats > Support thread for smafisnova](https://discord.com/channels/854659575324344340/1497237531169915011)
- Source: https://github.com/henkelmax/trade-cycling
# Other Licenses
Better Advancements
- Directory: assets/betteradvancements
- License: Don't Be a Jerk
- Source: https://github.com/way2muchnoise/BetterAdvancements